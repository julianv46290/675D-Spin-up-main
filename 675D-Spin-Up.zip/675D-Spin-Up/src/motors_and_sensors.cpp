#include "main.h"

pros::Motor flywheel = pros::Motor(flywheel_p, pros::E_MOTOR_GEARSET_06,
                                   true, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor intake = pros::Motor(intake_p, pros::E_MOTOR_GEARSET_06, true,
                                 pros::E_MOTOR_ENCODER_DEGREES);
pros::ADIDigitalOut indexer('H');
