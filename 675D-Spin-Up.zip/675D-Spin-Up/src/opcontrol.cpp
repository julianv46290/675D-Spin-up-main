/*
#include "main.h"
#include "pros/misc.h"
// flywheel speeds + intake/flywheel port placeholders
int high_speed = 12, low_speed = 9; // flywheel_port, intake_port;
int flywheel_p = 11;
int intake_p = 16;
// constructor for indexer pneum
//pros::ADIDigitalOut indexer('H');
// constructor for expansion pneum
//pros::ADIDigitalOut expansion('B');
//pros::Motor flywheel = pros::Motor(flywheel_p, pros::E_MOTOR_GEARSET_06,
                                  // true, pros::E_MOTOR_ENCODER_DEGREES);
//pros::Motor intake = pros::Motor(intake_p, pros::E_MOTOR_GEARSET_06, true,
                                // pros::E_MOTOR_ENCODER_DEGREES);


                void op_control() {
                                // roller_control();
                                   intake_control();
                                   flywheel_control();

                                   //need this to have op control thingy
                                 }





void flywheel_control() {



  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L1)) {
  //  flywheel.move_voltage(high_speed);
    flywheel.move_velocity(-500);
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
  //  flywheel  .move_voltage(low_speed);
       flywheel.move_velocity(-200);
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_X)) {
    indexer.set_value(false);
  } else {
  //  flywheel.move_voltage(0);
     flywheel.move_velocity(0);
    indexer.set_value(true);
  }
}
void intake_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
    intake.move_velocity(500);
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
    intake.move_velocity(-500);
  } else {
    intake.move_velocity(0);
  }
}
void expansion_control() {
  if (pros::E_CONTROLLER_DIGITAL_A == 1 && pros::E_CONTROLLER_DIGITAL_B == 1 &&
      pros::E_CONTROLLER_DIGITAL_LEFT == 1 &&
      pros::E_CONTROLLER_DIGITAL_DOWN == 1) {
    expansion.set_value(true);
  }
}


*/


























































#include "main.h"
#include "pros/misc.h"
// flywheel speeds + intake/flywheel port placeholders
int high_speed = 12, low_speed = 9; // flywheel_port, intake_port;
int flywheel_p = 11;
int intake_p = 16;
// constructor for indexer pneum
//pros::ADIDigitalOut indexer('H');
// constructor for expansion pneum
//pros::ADIDigitalOut expansion('B');
//pros::Motor flywheel = pros::Motor(flywheel_p, pros::E_MOTOR_GEARSET_06,
                                  // true, pros::E_MOTOR_ENCODER_DEGREES);
//pros::Motor intake = pros::Motor(intake_p, pros::E_MOTOR_GEARSET_06, true,
                                // pros::E_MOTOR_ENCODER_DEGREES);


                void op_control() {
                                // roller_control();
                                   intake_control();
                                   flywheel_control();

                                   //need this to have op control thingy
                                 }





void flywheel_control() {



  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
  //  flywheel.move_voltage(high_speed);
    flywheel.move_velocity(-360);
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
  //  flywheel  .move_voltage(low_speed);
       indexer.set_value(false);
  } else {
  //  flywheel.move_voltage(0);
    flywheel.move_velocity(0);
    indexer.set_value(true);
  }
}
void intake_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
    intake.move_velocity(550);
  } else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L1)) {
    intake.move_velocity(-550);
  } else {
    intake.move_velocity(0);
  }
}
void expansion_control() {
  if (pros::E_CONTROLLER_DIGITAL_A == 1 && pros::E_CONTROLLER_DIGITAL_B == 1 &&
      pros::E_CONTROLLER_DIGITAL_LEFT == 1 &&
      pros::E_CONTROLLER_DIGITAL_DOWN == 1) {
    expansion.set_value(true);
  }
}
