// extern bool flywheel;
// extern bool intake;
// extern bool indexer;
// extern bool expansion;
#include "api.h"
extern int high_speed;
extern int low_speed;
extern int flywheel_p;
extern int intake_p;
//pros::ADIDigitalOut indexer('H');



void op_control();
void flywheel_control();
void intake_control();
void expansion_control();
