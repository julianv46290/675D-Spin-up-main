#include "api.h"

extern pros::Motor flywheel;
extern pros::Motor intake;
extern pros::ADIDigitalOut indexer;
extern pros::ADIDigitalOut expansion;
extern pros::ADIDigitalOut piston_clamp;
extern pros::ADIDigitalOut piston_clamp1;
